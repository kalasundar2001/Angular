import { Component, OnInit } from '@angular/core';
import { Fruit } from '../FruitInterface';

@Component({
  selector: 'app-fruit-component',
  templateUrl: './fruit-component.component.html',
  styleUrls: ['./fruit-component.component.css']
})
export class FruitComponentComponent implements OnInit {
color='red';
f: Fruit = {
  name: "Apple",
  qty: 15
};
  constructor() { }

  ngOnInit(): void {
  }

}
