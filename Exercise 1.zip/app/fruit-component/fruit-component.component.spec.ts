import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FruitComponentComponent } from './fruit-component.component';

describe('FruitComponentComponent', () => {
  let component: FruitComponentComponent;
  let fixture: ComponentFixture<FruitComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FruitComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FruitComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
