export interface Fruit{
    name: string;
    qty:number;
}