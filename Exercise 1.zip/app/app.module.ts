import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { FruitComponentComponent } from './fruit-component/fruit-component.component';

import { FormsModule } from '@angular/forms';
import { VegiesComponent } from './vegies/vegies.component'; 

@NgModule({
  declarations: [
    AppComponent,
    FruitComponentComponent,
    VegiesComponent
  ],
  
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
