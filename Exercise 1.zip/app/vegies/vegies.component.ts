import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vegies',
  templateUrl: './vegies.component.html',
  styleUrls: ['./vegies.component.css']
})
export class VegiesComponent implements OnInit {
season="summer";
  constructor() { }

  ngOnInit(): void {
  }

}
