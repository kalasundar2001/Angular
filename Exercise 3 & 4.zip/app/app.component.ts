import { Component } from '@angular/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'One way Data Binding';
  temp="mystring";
  imgpath:string=' ';
  imgURL="http://pngimg.com/uploads/tiger/tiger_PNG23252.png";
  selectChangeHandler (event: any) {
  this.imgpath=event.target.value;
  if(this.imgpath=="Lion"){
    this.imgpath="http://pngimg.com/uploads/lion/lion_PNG23297.png";
  }
  else if(this.imgpath=="Tiger"){
   this.imgpath="http://pngimg.com/uploads/tiger/tiger_PNG23252.png";
  }
  else{
    this.imgpath="http://pngimg.com/uploads/dog/dog_PNG50412.png";
  }
}
}
