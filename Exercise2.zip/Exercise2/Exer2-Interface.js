var Employee = /** @class */ (function () {
    function Employee(n, i) {
        this.name = n;
        this.id = i;
    }
    Employee.prototype.display = function () {
        console.log("Name is " + this.name + ", ID: " + this.id + ", DOJ:  " + new Date());
    };
    return Employee;
}());
var employee = new Employee("kamala", 101);
employee.display();
