interface Emp{
  name:String;
  id: number;
  display();
}
class Employee implements Emp{
  name:String;
  id: number;
  constructor (n:string,i:number){
      this.name=n;
      this.id=i;
  }
  display(){
      console.log("Name is "+this.name+", ID: "+this.id+", DOJ:  "+new Date());
   }
} 
let employee:Employee=new Employee("kamala",101);
employee.display();